public class hw9 {

	public static int adder(***TODO***)
	{
		int sum = 0;
		
		***TODO***
		
		return sum;
	}
	public static void main(String [] args)
	{
		System.out.println("Sum 1 is " + adder(1,2,3,4,5,6));		
		System.out.println("Sum 2 is " + adder(1,5));		
		System.out.println("Sum 3 is " + adder());
	}
}
